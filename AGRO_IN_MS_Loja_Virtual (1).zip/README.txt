AGRO IN MS — SITE
===================

Informações da marca:
- Instagram: @agroinms
- YouTube: agroinms
- Loja: Campo Grande — Mato Grosso do Sul
- Criadores: @4ndres5a e @felipehammel

Arquivos:
- index.html
- assets/ (imagens fornecidas)

COMO USAR:
1. Abra index.html no navegador para visualizar o site.
2. Para publicar, envie a pasta inteira para um serviço de hospedagem de sites.
3. Antes de publicar, abra index.html e procure:
   const WHATSAPP_NUMBER = "5567999999999";
   Troque pelo número real do WhatsApp da loja, com DDI + DDD, sem espaços ou símbolos.

O site já inclui:
- Layout responsivo para celular e computador
- História da marca
- 4 produtos (masculina, feminina, infantil e boné)
- Preços informados
- Tamanhos
- Carrinho de compras
- Preparação de pedido via WhatsApp
- Instagram @agroinms

NOVOS RECURSOS DE LOJA:
- Comprar Agora
- Seleção de tamanho
- Seleção de quantidade
- Carrinho
- Cálculo de frete estimado
- Checkout com dados do cliente e endereço
- Opção de pagamento por Pix
- Finalização do pedido via WhatsApp

PIX:
Por segurança, a chave Pix não foi inventada. Para ativar, edite index.html e procure:
const PIX_KEY="";
Coloque a chave oficial entre as aspas.

FRETE:
O site usa R$ 20,00 apenas como estimativa provisória. Troque a regra antes de publicar se desejar cálculo real por CEP.
